public class data_rumah_sakit
{

    String Email;
    String Password;
    int Nomor_Medis;

    public data_rumah_sakit(String email,String password,int nomor_medis)
    {
        Email= email;
        Password = password;
        Nomor_Medis = nomor_medis;
    }
}
